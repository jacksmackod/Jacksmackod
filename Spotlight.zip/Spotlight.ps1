$ErrorActionPreference= 'silentlycontinue'

Write-Host "--------"

cd "C:\Users\Jack\Desktop\Spotlight"

ls *.* -recurse | get-filehash | group -property hash | where { $_.count -gt 1 } | % { $_.group | select -skip 1 } | del

$folder = 'C:\Users\Jack\Desktop\Spotlight'

$image = New-Object -ComObject Wia.ImageFile

$count = 0

$array = @()

$blank = ""

$pictures = Get-ChildItem $folder *.jpg | ForEach-Object {
    $image.LoadFile($_.fullname)
    $size = $image.Width.ToString() + 'x' + $image.Height.ToString()

    $heightGtWidth = if ([int]$image.Height.ToString() -gt [int]$image.Width.ToString()) {
        $true
		$count++
		$array += $_.name
		del -Path $_.fullname
    } else {
        $false
    }
	
	$small = if ([int]$image.Height.ToString() -le '1000' -and [int]$image.Width.ToString() -le '1000') {
		$true
		$count++
		$array += $_.name
		del -Path $_.fullname
	}
	else {
        $false
    }

    
}

$pictures



Write-Host "Deleted" $count.toString() "Files"

